Get-Date

Get-AzVM -Status

CD azure:\

dir

cd MySubscriptionName

dir

cd $HOME/clouddrive

New-Item helloworld.ps1

code ./helloworld.ps1

Get-AzResourceGroup | select ResourceGroupName