Remove-AzResourceGroup -Name 'arm-introduction-01' -Force -AsJob
Remove-AzResourceGroup -Name 'arm-introduction-02' -Force -AsJob
Remove-AzResourceGroup -Name 'arm-introduction-03' -Force -AsJob
Remove-AzResourceGroup -Name 'arm-introduction-04' -Force -AsJob