group=azure-load-balancer-introduction
az group delete -g $group