DROP TABLE Cars;
DROP TABLE Countries;
DROP TABLE Movies;
DROP TABLE ExportedTables;