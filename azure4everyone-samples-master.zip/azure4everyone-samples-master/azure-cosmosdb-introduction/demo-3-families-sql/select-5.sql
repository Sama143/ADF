SELECT value COUNT(child)
FROM child IN Families.children