group=azure-traffic-manager-introduction
az group delete -g $group